import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User;
  msg: string = "";

  constructor(private router: Router) {
    this.user= new User();
  }

  ngOnInit() {
    
  }
  
  login():void{
    let users=JSON.parse(localStorage.getItem('users'));
    let usr=this.user;
    if(usr.username == "" || usr.username == null || usr.password == "" || usr.password == null || usr.type == "" || usr.type == null){
      this.msg="Unesite sve podatke!";
      return;
    }
    if(users!=null){
        for(var i=0; i<users.length; i++){
          if(users[i].username==usr.username){
            if(users[i].password==usr.password){
              if(users[i].type==usr.type){
                if(users[i].type=='admin'){
                  localStorage.setItem('usrLgn',JSON.stringify(users[i]));
                  this.router.navigate(['admin']);
                }
                else if(users[i].type=='author'){
                  localStorage.setItem('usrLgn',JSON.stringify(users[i]));
                  this.router.navigate(['author']);
                }
              }
              else{
                this.msg="Nije dobar tip!";
                return;
              }
            } 
            else{
              this.msg="Nije dobar password!";
              return;
            }          
          }
        }
        this.msg="Ne postoji korisnik sa tim username-om!";
    }
    else{
      this.msg="Ne postoji baza korisnika";
    }
  }

}
