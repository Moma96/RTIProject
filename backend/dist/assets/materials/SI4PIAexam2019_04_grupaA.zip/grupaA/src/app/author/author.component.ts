import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-author',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.css']
})
export class AuthorComponent implements OnInit {

  books;
  user;

  constructor() { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem('usrLgn'));
    var listOfAllBooks=JSON.parse(localStorage.getItem('books'));
    this.books = [];
    for(let i=0;i<listOfAllBooks.length;i++){
      if(listOfAllBooks[i].author==this.user.username){
        var s = 1;
        for(let j = 0; j<listOfAllBooks[i].books.length; j++){
          var temp: any = {};
          
          temp.br = s;
          temp.naslov = listOfAllBooks[i].books[j];
          this.books.push(temp);
          s++;
        }
        
      }
    }
  }


}
