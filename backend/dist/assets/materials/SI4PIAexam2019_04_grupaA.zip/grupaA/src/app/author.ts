export class Author {
    author:string;
    books:any;
}
