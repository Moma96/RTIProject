import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Author } from '../author';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  books;
  user;
  ttl: string;
  author1: string;
  author2: string;
  authors= new Array<User>();
  msg: string;

  constructor() { 
    this.books = JSON.parse(localStorage.getItem('books'));
    this.user=JSON.parse(localStorage.getItem('usrLgn'));
    var listOfUsers=JSON.parse(localStorage.getItem('users'));
    for(let i=0;i<listOfUsers.length;i++){
      if(listOfUsers[i].type=='author'){
        this.authors.push(listOfUsers[i]);
      }
    } 
  }

  ngOnInit() {

  }

  dodaj():void{
    if(this.author1==this.author2){
      this.msg="Greska, isti autori izabrani!";
    }
    else{
      if(this.ttl=="" || this.ttl == null){
        this.msg = "Niste uneli naziv knjige";
      }
      else{
        var items=JSON.parse(localStorage.getItem('books'));
        for(let i=0; i<items.length; i++){
          if(items[i].author==this.author1){
            items[i].books.push(this.ttl);
          }
          if(items[i].author==this.author2){
            items[i].books.push(this.ttl);
          }
        }
  
        alert(JSON.stringify(items));
        localStorage.setItem('books',JSON.stringify(items));
        this.books=JSON.parse(localStorage.getItem('books'));
        this.msg = "Uspesno dodata knjiga";
      }
      
    }
  }
}
