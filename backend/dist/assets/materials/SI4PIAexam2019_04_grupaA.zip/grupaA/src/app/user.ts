export class User {
    fname:string;
    lname:string;
    username:string;
    password:string;
    type:string;
}
