import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'Akademska Misao';
  usrs=[
    {fname:"Petar",lname:"Marković",type:"author",username:"pera",password:"pera123"},
    {fname:"Nikola",lname:"Ranković",type:"author",username:"nikola",password:"nikola123"},
    {fname:"Lazar",lname:"Nikolić",type:"author",username:"laza",password:"laza123"},
    {fname:"Admin",lname:"Admin",type:"admin",username:"admin",password:"admin123"}
  ]
  bks=[
    {author:"pera",books:[ "Nevidljivi akademci", "Zimski vojnik"]},
    {author:"nikola",books:[  "Novi putevi svile","Kuća hiljadu maski", "Sve je ovde divno"]},
    {author:"laza",books:[   "Sve je ovde divno"," Put promene", "Balkanski špijun"]}
  ]
  
  ngOnInit() {
    localStorage.setItem('users',JSON.stringify(this.usrs));
    localStorage.setItem('books',JSON.stringify(this.bks));
  }
}
