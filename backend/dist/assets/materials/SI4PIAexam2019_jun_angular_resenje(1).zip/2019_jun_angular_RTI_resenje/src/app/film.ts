import { Zanr } from './zanr';

export class Film{
    idFilm: number;
    naziv: string;
    zemlja: string;
    godina: number;
    zanr: Zanr[];
}