import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlagajnikComponent } from './blagajnik.component';

describe('BlagajnikComponent', () => {
  let component: BlagajnikComponent;
  let fixture: ComponentFixture<BlagajnikComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlagajnikComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlagajnikComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
