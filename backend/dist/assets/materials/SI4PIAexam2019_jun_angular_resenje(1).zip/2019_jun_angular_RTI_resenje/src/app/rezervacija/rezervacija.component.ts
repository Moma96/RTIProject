import { Component, OnInit } from '@angular/core';
import { Rezervacija } from '../rezervacija';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rezervacija',
  templateUrl: './rezervacija.component.html',
  styleUrls: ['./rezervacija.component.css']
})
export class RezervacijaComponent implements OnInit {
  rezervacija: Rezervacija;

  constructor(private r: Router) { }

  ngOnInit() {
    this.rezervacija = JSON.parse(localStorage.getItem("poslednjaRezervacija"));
  }

  nazad(){
    this.r.navigate(["posetilac"]);
  }

}
