export class Korisnik{
    korisnicko_ime: string;
    lozinka: string;
    ime: string;
    prezime: string;
    zanimanje: string;
    tip: number;
}