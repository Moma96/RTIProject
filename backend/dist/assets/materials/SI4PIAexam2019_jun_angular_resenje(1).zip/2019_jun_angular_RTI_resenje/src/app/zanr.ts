export const enum Zanr{
    Akcioni, Avantura, Komedija, Triler, Drama, Dokumentarni
}