import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoviFilmComponent } from './novi-film.component';

describe('NoviFilmComponent', () => {
  let component: NoviFilmComponent;
  let fixture: ComponentFixture<NoviFilmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoviFilmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoviFilmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
