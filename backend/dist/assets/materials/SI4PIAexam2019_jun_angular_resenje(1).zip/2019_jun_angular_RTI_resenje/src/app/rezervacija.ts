export class Rezervacija{
    korisnik: string;
    naziv: string;
    idP: number;
    datum: Date;
    sala: string;
    vreme: number;
    broj: number;
}