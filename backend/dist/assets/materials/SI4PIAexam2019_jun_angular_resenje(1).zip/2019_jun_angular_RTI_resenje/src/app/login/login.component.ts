import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../korisnik';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  kor_ime: string;
  lozinka: string;
  tip: string;
  msg: string;

  constructor(private r: Router) { }

  ngOnInit() {
  }

  login(){
    let korisnici:Korisnik[]=JSON.parse(localStorage.getItem("korisnici"));

    for(var i=0; i<korisnici.length; i++){
      if(korisnici[i].korisnicko_ime==this.kor_ime){
        if(korisnici[i].lozinka==this.lozinka){
          if(korisnici[i].tip==parseInt(this.tip)){
            if(korisnici[i].tip==1){
              localStorage.setItem('user',JSON.stringify(korisnici[i]));
              this.r.navigate(['posetilac']);
            }
            else if(korisnici[i].tip==2){
              localStorage.setItem('user',JSON.stringify(korisnici[i]));
              this.r.navigate(['blagajnik']);
            }
          }
          else{
            this.msg="Nije dobar tip!";
            return;
          }
        } 
        else{
          this.msg="Nije dobar password!";
          return;
        }          
      }
    }
    this.msg="Ne postoji korisnik sa tim username-om!";
  }

}
