export class Projekcija{
    idPr: number;
    idFilma: number;
    datum: Date;
    vreme: number;
    sala: string;
}