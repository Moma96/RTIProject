import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blagajnik',
  templateUrl: './blagajnik.component.html',
  styleUrls: ['./blagajnik.component.css']
})
export class BlagajnikComponent implements OnInit {
  projekcije: any[];
  msg: string;

  constructor(private r: Router) { }

  ngOnInit() {
    var filmovi = JSON.parse(localStorage.getItem("filmovi"));
    this.projekcije = [];
    for(var i=0; i<filmovi.length; i++){
        var projekcije = JSON.parse(localStorage.getItem("projekcije"));
        for(var j=0; j<projekcije.length; j++){
          if(projekcije[j].idFilma==filmovi[i].idFilm){
              var temp: any = {};
 
              temp.naziv = filmovi[i].naziv;
              temp.datum = projekcije[j].datum;
              temp.vreme = projekcije[j].vreme;
              temp.sala = projekcije[j].sala;
              temp.broj=0;

              var rezervacije = JSON.parse(localStorage.getItem("rezervacije"));
              for(var k=0; k<rezervacije.length; k++){
                if(rezervacije[k].idP==projekcije[j].idPr){
                  temp.broj+=2;
                }
              }

              this.projekcije.push(temp);
                      
          }
        }
      
    }   
  }

  logout(){
    this.r.navigate([""]);
  }

  novo(){
    this.r.navigate(["noviFilm"]);
  }

}
