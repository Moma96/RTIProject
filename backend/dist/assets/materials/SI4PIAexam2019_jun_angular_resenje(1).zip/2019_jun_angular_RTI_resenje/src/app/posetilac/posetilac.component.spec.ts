import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosetilacComponent } from './posetilac.component';

describe('PosetilacComponent', () => {
  let component: PosetilacComponent;
  let fixture: ComponentFixture<PosetilacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosetilacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosetilacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
