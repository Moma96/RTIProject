import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PosetilacComponent } from './posetilac/posetilac.component';
import { BlagajnikComponent } from './blagajnik/blagajnik.component';
import { RezervacijaComponent } from './rezervacija/rezervacija.component';
import { NoviFilmComponent } from './novi-film/novi-film.component';

const routes: Routes = [
  {path:"", component: LoginComponent},
  {path:"posetilac", component: PosetilacComponent},
  {path:"blagajnik", component: BlagajnikComponent},
  {path:"rezervacija", component: RezervacijaComponent},
  {path:"noviFilm", component: NoviFilmComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
